/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/background.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/background.ts":
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/
/*! exports provided: registerBackground */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "registerBackground", function() { return registerBackground; });
const tabPorts = {};
function registerBackground() {
  chrome.runtime.onConnect.addListener(backgroundPort => {
    function handleMessage(message, clientPort) {
      var _clientPort$sender2, _clientPort$sender2$t, _tabPorts;

      if (message.action === 'registerTab') {
        var _clientPort$sender, _clientPort$sender$ta;

        if (((_clientPort$sender = clientPort.sender) === null || _clientPort$sender === void 0 ? void 0 : (_clientPort$sender$ta = _clientPort$sender.tab) === null || _clientPort$sender$ta === void 0 ? void 0 : _clientPort$sender$ta.id) && !(clientPort.sender.tab.id.toString() in tabPorts)) {
          tabPorts[clientPort.sender.tab.id.toString()] = clientPort;
        }

        return;
      }

      if (typeof message.action === 'undefined') return;
      const tabId = message.tabId || ((_clientPort$sender2 = clientPort.sender) === null || _clientPort$sender2 === void 0 ? void 0 : (_clientPort$sender2$t = _clientPort$sender2.tab) === null || _clientPort$sender2$t === void 0 ? void 0 : _clientPort$sender2$t.id);
      if (typeof message.tabId === 'undefined') return;
      return (_tabPorts = tabPorts[(tabId === null || tabId === void 0 ? void 0 : tabId.toString()) || '']) === null || _tabPorts === void 0 ? void 0 : _tabPorts.postMessage(message);
    }

    backgroundPort.onMessage.addListener(handleMessage);
    backgroundPort.onDisconnect.addListener(port => {
      port.onMessage.removeListener(handleMessage);
      Object.keys(tabPorts).forEach(tabIdString => {
        if (tabPorts[tabIdString] == port) delete tabPorts[tabIdString];
      });
    });
  });
}
registerBackground();

/***/ })

/******/ });
//# sourceMappingURL=background.js.map